#!/usr/bin/env python
# -*- coding: utf-8 -*-

from Bio.Seq import Seq
import sys
import re
import csv


# global variables
T = 37; # temperature(C)
sequences={}
windowL = 15;  # window length, http://www.biomedcentral.com/1471-2105/6/1

cutoff_D = 3.4
cutoff_E1 = -15.99 
NNparams={'AA/TT':[-7.9, -22.2],
'AT/TA':[-7.2,-20.4],
'TA/AT':[-7.2,-21.3], 
'CA/GT':[-8.5,-22.7],
'GT/CA':[-8.4,-22.4],
'CT/GA':[-7.8,-21.0],
'GA/CT':[-8.2,-22.2],
'CG/GC':[-10.6,-27.2],
'GC/CG':[-9.8,-24.4],
'GG/CC':[-8.0,-19.9],
 #initiation costs
'G':[ 0.1,-2.8 ],
'A':[2.3,4.1],
# symmetry correction
'sym':[0,-1.4]} 


## open file
my_file=open(sys.argv[1], 'r')
print "#parameters: Temperature %s." % T,"Window=%s" % windowL, "\n\n";

#open(SEQ, my_file)


# calculate NN free energy of a DNA duplex , dG(t) = (1000*dH - t*dS) / 1000
# parameters: 1) DNA sequence string; 2) Celsius temperature
# returns; 1) free energy scalar
# uses global hash %NNparams


## calcula reverso complementario
alt_map = {'ins':'0'}
complement_dict = {'A': 'T', 'C': 'G', 'G': 'C', 'T': 'A'} 

def complement(seq):    
    for k,v in alt_map.iteritems():
        seq = seq.replace(k,v)
    bases = list(seq) 
    bases = reversed([complement_dict.get(base,base) for base in bases])
    bases = ''.join(bases)
    for k,v in alt_map.iteritems():
        bases = bases.replace(v,k)
    return bases

## calcula dG
def duplex_deltaG(sequence,tCelsius):
	tK = 273.15 + tCelsius
	total_dG = 0
	for y in range(1, len(sequence)):
		DNAstep = sequence[y-1]+sequence[y]+'/'+complement(sequence[y-1])+complement(sequence[y])
		if DNAstep not in NNparams.keys():
			DNAstep = DNAstep[::-1]
			dG = float((1000*NNparams[DNAstep][0])-float(tK*NNparams[DNAstep][1]))/1000
		else:
			dG = float((1000*NNparams[DNAstep][0])-float(tK*NNparams[DNAstep][1]))/1000
		total_dG += dG 
	return total_dG

	    
## calcula D_n, E1_n y E2_n para cada secuencia, filtra por cut-off e imprime en file
listaDeltaG = open('listaDG', 'a')
D_dG = {}
#valores de cutoff
cutoffD = 0.20
cutoffE1 = -17.15
# output files
Predictions = open("Predictions_0.20_17.15.txt", "a")
Data =  open("Totales_0.20_17.15.txt", "a")	
FalsePositives = open("FP_0.20_17.15.txt", "a")

# crea un diccionario de secuencias, key = name, value = seq 
for line in my_file:
	name = line.split('\ ',2)[0]
	seq = line.split('\ ',2)[1]
	sequences[name] = seq
	n=1
	listaDG = []
# guarda en una lista el cálculo de DG para cada sitio
	for i in range(n, 436):
		window = seq[n:n+15]
		deltaG = duplex_deltaG(window,T)
		listaDG.append(deltaG)
		n+=1
# la lista de DG de cada secuencia se agrega a un diccionario
	D_dG[name] = listaDG

	i = 0
	D={}
# recorre las secuencias calculando Dn, E1n y E2n
	for i in range(0,350):			
		E1 = listaDG[i:i+50]
		E1_n = sum(E1)/50
		E2 = listaDG[i+99:i+199]
		E2_n = sum(E2)/100
		D_n = E1_n - E2_n
		D[i]=[D_n,E1_n,E2_n]
		Data.write('{0} {1} {2} {3} {4} {5} {6} {7}\n'.format(name,i, D_n, E1_n,E2_n ,seq[i+50:i+99],i+50,i+99))
# Guarda las predicciones de promotores en un archivo : Predictions		
		if D_n > cutoffD and E1_n > cutoffE1:
			if i+50 > 250 and i+99 < 450:
				Predictions.write('{0} {1} {2} {3} {4} {5} {6} {7}\n'.format(name,i, D_n, E1_n,E2_n ,seq[i+50:i+99],i+50,i+99))
			else:
				FalsePositives.write('{0} {1} {2} {3} {4} {5} {6}\n'.format(name, D_n, E1_n,E2_n ,seq[i+50:i+99],i+50,i+99))
				
		
		i+=1
		



## guardo en csv los DG para cada sitio y secuencia
import csv
w = csv.writer(open("output.csv", "w"))
for key, val in D_dG.items():
    w.writerow([key, val])

# close files
Predictions.close()
Data.close()



